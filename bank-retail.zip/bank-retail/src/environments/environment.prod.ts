export const environment = {
  production: true,
  baseUrl: 'http://3.109.209.153:3000'
};
